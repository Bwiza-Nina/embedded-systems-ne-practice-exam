const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const cors = require('cors');

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cors());

// Initialize an empty array to store the data entries
const dataEntries = [];

app.get("/", (req, res) => {
  res.send("Welcome to the backend");
});

app.post('/data', (req, res) => {
  const temperature = req.body.temperature;
  const humidity = req.body.humidity;

  console.log("Temperature: " + temperature + "  Humidity: " + humidity);

  // Create a new data entry object
  const entry = {
    date: new Date().toISOString(),
    temperature: temperature,
    humidity: humidity
  };

  // Push the new entry to the dataEntries array
  dataEntries.push(entry);

  // Send the entire dataEntries array as the response
  res.status(200).json(dataEntries);
});

app.listen(3000, () => {
  console.log('Server is running on port 3000');
});
